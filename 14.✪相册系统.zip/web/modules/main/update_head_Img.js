define(function (require, exports, module) {
    // 引入工具
    var tools = require("modules/tools/tools");
    var Observer = tools.Observer;

    // 获取元素
    // var $headPic = $('#headPic');

    // 注册图片更改事件
    // Observer.on('changeHeadPic', function (newPath) {
    //     $headPic.attr("src", newPath);
    // })

});